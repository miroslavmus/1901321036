﻿using System;
using System.Collections.Generic;

namespace Ex2
{
    class Program
    {
        static string InputHandle(ref string input)
        {
            // Console.WriteLine(input); //debug

            string output = "";
            char[] raw = input.ToCharArray();
            int i;
            for (i = 0; ' ' != raw[i]; ++i)
            {
                output += raw[i];
            }

            input = "";
            for (int j = i + 1; j < raw.Length; ++j)
            {
                input += raw[j];
            }

            // Console.WriteLine(input); // debug
            return output.ToLower();
        }

        static void Main(string[] args)
        {
            string command = "";
            Dictionary<string, int> Lex = new Dictionary<string, int>();
            do
            {
                Console.WriteLine("Please enter:");
                command = Console.ReadLine();
                if (command.ToLower().Equals("end") || command.Equals(""))
                {
                    break;
                }

                string product = InputHandle(ref command);
                int quant;
                try
                {
                    quant = Convert.ToInt32(command);
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid quantity");
                    continue;
                }

                try
                {
                    Lex.Add(product, quant);
                }
                catch (Exception)
                {
                    Lex[product] += quant;
                }
            } while (true);
            Console.Clear();
            Console.WriteLine("Product: \tQ/ty:" );
            while (Lex.Count > 0)
            {
                string key = findLargest(Lex);
                Console.WriteLine(key+" \t\t"+Lex[key]);
                Lex.Remove(key);
            }
            

        }

        static string findLargest(Dictionary<string, int> arr)
        {
            string maxvalkey = "";
            int maxval = int.MinValue;
            foreach (var v in arr)
            {
                if (maxval < v.Value)
                {
                    maxval = v.Value;
                    maxvalkey = v.Key;
                }
            }

            return maxvalkey;
        }
    }
}
