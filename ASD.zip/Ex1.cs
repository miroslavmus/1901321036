﻿using System;

namespace Ex1
{
    class Program
    {
        static int column(int[,] arr, int col)
        {
            int output = int.MaxValue;
            for (int i = 0; i < arr.GetLength(0); ++i)
            {
                if (output > arr[i, col])
                {
                    output = arr[i, col];
                }
            }
            return output;
        }
        static void Main(string[] args)
        {
            int Min = 0;
            int Max = 20;
            //int n = 5, m = 5;
            int[,] arr = new int[5, 5];

            Random randNum = new Random();

            for (int i = 0; i < arr.GetLength(0); i++)
            {

                int j = 0;
                for (; j < arr.GetLength(1); j++)
                {
                    arr[i, j] = randNum.Next(Min, Max);
                    Console.Write(" " + arr[i, j] + "\t");
                }



                Console.WriteLine();
            }

            int[] minval = new int[arr.GetLength(1)];
            for (int k = 0; k < minval.Length; k++)
            {
                minval[k] = column(arr, k);
                Console.WriteLine("Kolona k {0} ima za minimalen element : {1}", k + 1, minval[k]);
            }






        }
    }
}
