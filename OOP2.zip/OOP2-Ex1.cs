﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Subjects
{
    class Student
    {
        private string name;
        public string Facnum { get; private set; }
        private string subject;
        public float grade { get; private set; }

        public override string ToString()
        {

            return Facnum + name + " has " + grade + " in " + subject;
        }

        public Student(string input)
        {
            
            try
            {
                subject = InputHandle(ref input); //* asterisk != asteriks i obeliks
                name = InputHandle(ref input);
                Facnum = InputHandle(ref input);
                grade = float.Parse(input);
                
                
            }
            catch (Exception e)
            {
                Console.WriteLine("You probably screwed with the input.... You sly mf... :D\nException is: {0}\n...just in the odd case you were wondering...\nHave a splendid day!", e);
                throw new ArgumentException("Program terminated!");
            }
        }
        private string InputHandle(ref string input)
        {
            // Console.WriteLine(input); //debug

            string output = "";
            char[] raw = input.ToCharArray();
            int i;
            for (i = 0; !('=' == raw[i] || '>' == raw[i + 1]); ++i)
            {
                output += raw[i];
                //csharp oop
            }

            input = "";
            for (int j = i + 2; j < raw.Length; j++)
            {
                input += raw[j];
            }

            // Console.WriteLine(input); // debug
            return output;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the program!");
            string command = "";
            Dictionary<string, Student> Lex = new Dictionary<string, Student>();
            // key , value

            do
            {
                Console.WriteLine("Please enter:");
                command = Console.ReadLine();
                if (command.ToLower().Equals("end") || command.Equals(""))
                {
                    break;
                }
                Student s = new Student(command);
                try
                {
                    Lex.Add(s.Facnum, s);
                }
                catch (Exception)
                {
                    Console.WriteLine("Error!");
                }
                
            } while (true);
            
            ArrayList arr = new ArrayList();
            int i = 0;
            foreach (var v in Lex)
            {

                arr.Add(v.Value);
            }
            Lex.Clear();
            Student[] list = sort(arr);
            foreach (var v in list)
            {
                Console.WriteLine(v.ToString());
            }

        }
        static Student[] sort(ArrayList list)
        {
            float max = -1;
            var arr = new Student[list.Count];
            for (int i = 0; i < arr.Length; ++i)
            {
                int rm = 0;
                
                for (int j = 0; j < list.Count; ++j)
                {
                    if (((Student)list[j]).grade > max)
                    {
                        max = ((Student)list[j]).grade;
                        rm = j;
                    }

                }

                max = -1;
                arr[i] = (Student)list[rm];
                list.RemoveAt(rm);

            }

            return arr;
        }
    }
}
//programata ne mi furli exsepshan pred óra!



