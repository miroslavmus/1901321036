﻿using System;
using System.Collections.Generic;

namespace Ex3
{
    class Program
    {
        static string InputHandle(ref string input)
        {
            //Console.WriteLine(input); //debug

            string output = "";
            char[] raw = input.ToCharArray();
            int i;
            for (i = 0; !(i >= raw.Length || ' ' == raw[i]); ++i)
            {
                output += raw[i];
            }

            input = "";
            for (int j = i + 1; j < raw.Length; ++j)
            {
                input += raw[j];
            }

            //Console.WriteLine(input); // debug
            return output.ToLower();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your input:");
            string input = Console.ReadLine();
            Dictionary<string, int> Lex = new Dictionary<string, int>();

            while (input.Length > 0)
            {
                string cand = InputHandle(ref input);
                try
                {
                    Lex.Add(cand, 1);
                }
                catch (Exception)
                {
                    if (cand == null || cand.Equals("") || cand.Equals(" "))
                    {
                        continue;
                    }
                    ++Lex[cand];
                }
            }

            string buffer = "";
            foreach (var v in Lex)
            {
                if (v.Value % 2 == 1)
                {
                    buffer += v.Key + ", ";
                }
            }

            Console.WriteLine(buffer.Remove(buffer.Length - 2));



           

        }
    }
}
