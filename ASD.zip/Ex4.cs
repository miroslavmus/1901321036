﻿using System;
using System.IO.Enumeration;
using System.Linq.Expressions;

namespace Ex4
{
    class Program
    {
        /*
         * На случаен принцип се генерира масив от 10 елемента които са от целочислен тип.
         *A)Напишете метод, който пресмята средната стойност на масива.(Сумата на елементите делена на броя елементи)
         *Б)Напишете метод, който проверява дали дадено число се съдържа в масива. Метода връща индекса, ако има такова число и -1, ако го няма.
         *В)Напишете метод, който прехвърля стойностите от масив А в масив Б.
         *Е)Напишете метод, който намира 2рия най - малък елемент на масива (Без да го сортираме)
         *
         */
        static int[] GenRndArr(int size = 10, int bound = 50)
        {
            int[] arr = new int[size];
            Random rnd = new Random();
            for (int i = 0; i < arr.Length; ++i)
            {
                arr[i] = rnd.Next(bound);
            }
            return arr;
        }

        static double Average(int[] arr)
        {
            double average = 0;
            foreach (var v in arr)
            {
                average += v;
            }
            return average/arr.Length;
        }

        static int Contains(int[] arr, int a)
        {
            for (var index = 0; index < arr.Length; ++index)
            { 
                if (a == arr[index]) return index;
            }

            return -1;
        }

        static void Copy(ref int[] from, ref int[] to)
        {
            int[] ff = from;
            int[] newarr;
            newarr = new int[ff.Length + to.Length];

            for (int i = 0; i < to.Length; ++i)
            {
                newarr[i] = to[i];
            }

            for (int i = 0; i < ff.Length; ++i)
            {
                newarr[i + to.Length] = ff[i];
            }

            from = ff;
            to = newarr;
        }

        static void print(int[] arr)
        {
            string buffer = "";
            foreach (var v in arr)
            {
                buffer += v + ", ";
            }

            Console.WriteLine( buffer.Remove(buffer.Length - 2) + ';');
        }
        static int secondLowest(ref int[] arrinput)
        {
            int[] arr = arrinput;
            int element = Int32.MaxValue;
            int min = Int32.MaxValue;

            for (int i = 0; i < arr.Length; i++)
            {
                if (min > arr[i])
                {
                    min = arr[i];
                }
            }

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == min)
                {
                    arr[i] = int.MaxValue;
                }

                if (arr[i] < element)
                {
                    element = arr[i];
                }
            }

            return element;
        }
        static void Main(String[] args)
        {
            Random rnd = new Random();
            int[] arr1 = GenRndArr();
            int[] arr2 = GenRndArr(5,13);
            print(arr1);
            print(arr2);
            Console.WriteLine("Average of array 1 is {0}", Average(arr1));
            Console.WriteLine("Average of array 2 is {0}", Average(arr2));
            int a = arr1[rnd.Next(arr1.Length)];
            int b = Contains(arr1, a);
            Console.WriteLine("Check if there is a {0} in the array : {1}", a, b != -1? "Yes, at: " + (b+1) : "No, " + b  );
            a = 13;
            b = Contains(arr1, a);
            Console.WriteLine("Check if there is a {0} in the array : {1}", a, b != -1 ? "Yes, at: " + (b+1) : "No, " + b);
            print(arr1);
            Copy(ref arr1, ref arr2);
            print(arr2);
            Copy(ref arr2, ref arr1);
            print(arr1);
            print(arr2);
            Console.WriteLine("Second lowest of /\\ == " + secondLowest(ref arr2));
            print(arr1);
            Console.WriteLine("Second lowest of /\\ == " + secondLowest(ref arr1));

        }
    }
}
